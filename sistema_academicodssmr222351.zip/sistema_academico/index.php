<?php
require_once __DIR__ . '/php/session.php'; //esto para que solo se cargue una vez y llame el archivo session.php 

$registros = ss_get('registros', []);  // donde se guarda el registro de el estudiante 
$warnings  = ss_get('warnings', []); // donde notifica al usuario si a cometido algun error al intentar ingresar los datos 
$stats     = ss_get('stats', null);
$ranking   = ss_get('ranking', []); // donde se guarda la informacion los resultados del grupo de los estudiantes 

$flash_ok    = ss_get('flash_ok', null);
$flash_error = ss_get('flash_error', null);
$goto        = ss_get('goto', null);

unset($_SESSION['flash_ok'], $_SESSION['flash_error'], $_SESSION['goto']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sistema Academico </title>
<link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/styles.css">
</head>
<body>
  <!-- pantalla de inicio -->
<div class="grid-bg"></div>
<div class="preview-bar">
  <span>Menu:</span>
  <button class="ptab on" onclick="ir('home',this)">Inicio</button>
  <button class="ptab" onclick="ir('registro',this)">Registro</button>
  <button class="ptab" onclick="ir('estadisticas',this)">Estadísticas</button>
  <button class="ptab" onclick="ir('ranking',this)">Ranking</button>
</div>

<div class="page active" id="p-home">
<div class="wrap">
  <header>
    <div class="iph xl"></div>
    <div class="badge">DSS404 G06L</div>
    <h1>Sistema de Registro<br>y Evaluacion Academica</h1>
    <p>Desafio 1</p>
  </header>
  <div class="nav-cards">
    <div class="nav-card c-r" onclick="ir('registro',document.querySelectorAll('.ptab')[1])">
      <div class="iph lg"></div>
      <h3>Registro de Estudiantes</h3>
    </div>
    <div class="nav-card c-e" onclick="ir('estadisticas',document.querySelectorAll('.ptab')[2])">
      <div class="iph lg"></div>
      <h3>Estadísticas</h3>
    </div>
    <div class="nav-card c-k" onclick="ir('ranking',document.querySelectorAll('.ptab')[3])">
      <div class="iph lg"></div>
      <h3>Ranking Automatico</h3>
    </div>
  </div>
</div>
</div>
 <!-- pagina de registro de notas de el estudiante -->
<div class="page" id="p-registro">
<div class="topbar">
  <button class="btn-back" onclick="ir('home',document.querySelectorAll('.ptab')[0])">Inicio</button>
  <span class="topbar-title">Registro de Estudiantes</span>
</div>
<div class="wrap">
  <header>
    <div class="iph xl"></div>
    <div class="badge">Desafio 1 </div>
    <h1>Registro de notas de el <br>Estudiante</h1>
  </header>

  <?php if ($flash_ok): ?>
    <div class="alert as"><?php echo $flash_ok; ?></div>
  <?php endif; ?>

  <?php if ($flash_error): ?>
    <div class="alert ae"><?php echo htmlspecialchars($flash_error); ?></div>
  <?php endif; ?>

  <?php if (!empty($warnings)): ?>
    <div class="alert ae" style="border-left-color:#fbbf24;color:#fbbf24;background:rgba(251,191,36,.08)">
      <?php echo implode("<br>", array_map('htmlspecialchars', $warnings)); ?>
    </div>
  <?php endif; ?>

  <div class="card">
    <div class="stitle"><div class="iph md"></div>Datos del Estudiante</div>

    <form method="POST" action="php/app.php">
      <div class="fgrid">
        <div class="fb ff">
          <label class="fl">Nombre completo del estudiante</label>
          <input type="text" name="nombre" value="" placeholder="">
          <small style="font-size:.56rem;color:var(--muted)">Solo letras y espacios. Sin numeros ni simbolos.</small>
        </div>

        <div class="fb">
          <label class="fl">Materia</label>
          <select name="materia">
            <option value="">Selecciona una materia</option>
            <option>Programacion</option>
            <option>Base de Datos</option>
            <option>Redes</option>
            <option>Matematica</option>
          </select>
          <small style="font-size:.56rem;color:var(--muted)">Elige la materia a registrar.</small>
        </div>
        <!-- para darle instrucciones al usuario de como debe ingresar una calificacion -->
        <div class="fb">
          <div class="info-box">
            <small style="font-size:.63rem;color:var(--muted);line-height:1.8">
              Las notas deben estar entre <strong style="color:#00e5ff">0</strong> y <strong style="color:#00e5ff">10</strong>.<br>
              Notas invalidas se reemplazan por <strong style="color:#fbbf24">0</strong> automaticamente.
            </small>
          </div>
        </div>

        <div class="ff">
          <label class="fl" style="margin-bottom:.6rem;display:block">Notas del estudiante</label>
          <div class="nrow">
            <div class="nb"><span class="fl">Nota 1</span><input type="number" name="n1" value="0" min="0" max="10" step="0.1"></div>
            <div class="nb"><span class="fl">Nota 2</span><input type="number" name="n2" value="0" min="0" max="10" step="0.1"></div>
            <div class="nb"><span class="fl">Nota 3</span><input type="number" name="n3" value="0" min="0" max="10" step="0.1"></div>
            <div class="nb"><span class="fl">Nota 4</span><input type="number" name="n4" value="0" min="0" max="10" step="0.1"></div>
          </div>
        </div>
      </div>

      <div class="bgroup">
        <button class="bp" type="submit" name="accion" value="agregar">Enviar Registro</button> <!-- al momento de darle click se guarda los datos de el estudiante -->
        <button class="bs" type="submit" name="accion" value="limpiar">Limpiar</button> <!-- solo borra los datos de un estudiante -->
      </div>
    </form>
  </div>
  <!-- tabla de estudiantes registrados  -->
  <div class="card">
    <div class="stitle">Estudiantes Registrados
      <span style="margin-left:auto;font-size:.65rem;color:var(--muted)"><?php echo count($registros); ?> registros</span> 
    </div>

    <div class="rlist">
      <?php if (count($registros) === 0): //utilizamos la condicion if si ningun estudiante se a registrado ?>
         <!-- pueda mostrar este mensaje -->
        <div class="empty">Aún no hay registros.</div>
      <?php else: // si alguien empieza a ingresar los datos de el estudiante ?>
        <?php foreach ($registros as $i => $r): ?>
          <?php // el programa en automatimente hace las sumas de las 4 notas y las divide en 4 para sacar el promedio final
            $prom = round(($r['n1'] + $r['n2'] + $r['n3'] + $r['n4']) / 4 );
               // dependiendo cual sea el promedio final de el estudiante se va catalogando su rendimiento academico 
               // usamos switch para  obtener una comparacion con una serie de valores que ya hemos predefinido
            switch (true) {
              case ($prom >= 9): $cat = "Alto Rendimiento"; $catClass="cat-alto"; break;
              case ($prom >= 8): $cat = "Satisfactorio";    $catClass="cat-sat"; break;
              case ($prom >= 7): $cat = "Basico";          $catClass="cat-basico"; break;
              default:           $cat = "Bajo";            $catClass="cat-bajo"; break;
            }

            $chip = function($n){
              if ($n >= 8) return "h";
              if ($n >= 6) return "m";
              return "l";
            };
          ?>
          <div class="ri">
            <div class="rnum"><?php echo $i + 1; ?></div>
            <div class="rname"><strong><?php echo htmlspecialchars($r['nombre']); ?></strong><span><?php echo htmlspecialchars($r['materia']); ?></span></div>

            <div style="display:flex;gap:.4rem;flex-wrap:wrap">
              <span class="np <?php echo $chip($r['n1']); ?>">N1: <?php echo $r['n1']; ?></span>
              <span class="np <?php echo $chip($r['n2']); ?>">N2: <?php echo $r['n2']; ?></span>
              <span class="np <?php echo $chip($r['n3']); ?>">N3: <?php echo $r['n3']; ?></span>
              <span class="np <?php echo $chip($r['n4']); ?>">N4: <?php echo $r['n4']; ?></span>
            </div>

            <div class="rprom"><?php echo number_format($prom, 2); ?></div>
            <span class="bc <?php echo $catClass; ?>"><?php echo $cat; ?></span>

            <form method="POST" action="php/app.php">
              <input type="hidden" name="accion" value="eliminar">
              <input type="hidden" name="idx" value="<?php echo $i; ?>">
              <button class="bd" type="submit">Eliminar</button>
            </form>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <div style="margin-top:1.2rem">
      <form method="POST" action="php/app.php">
        <input type="hidden" name="accion" value="eliminar_todos">
        <button class="bd" type="submit">Eliminar todos los registros</button>
      </form>
    </div>
  </div>
</div>
</div>

<div class="page" id="p-estadisticas">
<div class="topbar">
  <button class="btn-back" onclick="ir('home',document.querySelectorAll('.ptab')[0])">Inicio</button>
  <span class="topbar-title">Estadísticas del Grupo</span>
</div>
<div class="wrap">
  <header>
    <div class="iph xl"></div>
    <div class="badge">Desafio 1 </div>
    <h1>Estadisticas<br>del Grupo</h1>
    <p>Analisis completo  <?php echo count($registros); ?> estudiantes registrados</p>
  </header>

  <?php if ($stats && !empty($stats['mensajes'])): ?>
    <?php foreach ($stats['mensajes'] as $m): ?>
      <div class="mc <?php echo $m['tipo']; ?>"><?php echo htmlspecialchars($m['texto']); ?></div>
    <?php endforeach; ?>
    <div style="height:1rem"></div>
  <?php endif; ?>

  <div class="card">
    <div class="stitle"><div class="iph md"></div>Tabla de Detalle Academico</div>
    <div class="tw">
      <table>
        <thead><tr>
          <th>Nombre</th><th>Materia</th>
          <th style="text-align:center">Nota 1</th>
          <th style="text-align:center">Nota 2</th>
          <th style="text-align:center">Nota 3</th>
          <th style="text-align:center">Nota 4</th>
          <th>Promedio</th><th>Categoría</th><th style="text-align:center">Reprobo</th>
        </tr></thead>
        <tbody>
          <?php if (!$stats): ?>
            <tr><td colspan="9" class="esvacio">Registra mínimo 5 estudiantes para ver estadísticas.</td></tr>
          <?php else: ?>
            <?php foreach (($stats['detalle'] ?? []) as $e): ?>
              <?php
              // usamos switch para que compare valores ya predefinidos como la categoria de el rendimiento academico de el estudiante 
                switch ($e['categoria']) {
                  case "Alto Rendimiento": $catClass="cat-alto"; break;
                  case "Satisfactorio":    $catClass="cat-sat"; break;
                  case "Basico":          $catClass="cat-basico"; break;
                  default:                $catClass="cat-bajo"; break;
                }
                $repTxt = $e['reprobo'] ? "Si" : "No";
                $repColor = $e['reprobo'] ? "var(--danger)" : "var(--success)";
              ?>
              <tr>
                <td style="font-weight:700"><?php echo htmlspecialchars($e['nombre']); ?></td>
                <td style="color:var(--accent3);font-size:.7rem"><?php echo htmlspecialchars($e['materia']); ?></td>
                <td class="nc"><?php echo $e['n1']; ?></td>
                <td class="nc"><?php echo $e['n2']; ?></td>
                <td class="nc"><?php echo $e['n3']; ?></td>
                <td class="nc"><?php echo $e['n4']; ?></td>
                <td class="an"><?php echo number_format($e['promedio'], 2); ?></td>
                <td><span class="bc <?php echo $catClass; ?>"><?php echo $e['categoria']; ?></span></td>
                <td style="text-align:center;color:<?php echo $repColor; ?>;font-size:.72rem"><?php echo $repTxt; ?></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <div class="card">
    <div class="stitle"><div class="iph md"></div>Sección Estadística</div>
    <div class="sgrid">
      <div class="sc">
        <div class="sl">Promedio General</div>
        <div class="sv"><?php echo $stats ? number_format($stats['prom_general'], 2) : '—'; ?></div>
        <div class="ss">sobre 10.00</div>
      </div>
      <div class="sc">
        <div class="sl">Mejor Estudiante</div>
        <div class="sv" style="font-size:1.05rem;color:var(--success)"><?php echo ($stats && $stats['mejor']) ? htmlspecialchars($stats['mejor']['nombre']) : '—'; ?></div>
        <div class="ss">Promedio: <?php echo ($stats && $stats['mejor']) ? number_format($stats['mejor']['promedio'], 2) : '—'; ?></div>
      </div>
      <div class="sc">
        <div class="sl">Menor Promedio</div>
        <div class="sv" style="font-size:1.05rem;color:var(--accent2)"><?php echo ($stats && $stats['peor']) ? htmlspecialchars($stats['peor']['nombre']) : '—'; ?></div>
        <div class="ss">Promedio: <?php echo ($stats && $stats['peor']) ? number_format($stats['peor']['promedio'], 2) : '—'; ?></div>
      </div>
      <div class="sc">
        <div class="sl">% Reprobación</div>
        <div class="sv"><?php echo $stats ? ($stats['porc_reprob'].'%') : '—'; ?></div>
        <div class="ss"><?php echo $stats ? ($stats['reprobados'].' de '.$stats['total'].' estudiantes') : '—'; ?></div>
        <div class="rb"><div class="rf" style="width:<?php echo $stats ? $stats['porc_reprob'] : 0; ?>%"></div></div>
      </div>
    </div>

    <div class="stitle" style="margin-top:.5rem">Conteo por Categoría</div>
    <div class="cr"><span class="bc cat-alto">Alto Rendimiento</span><span style="font-weight:700"><?php echo $stats ? ($stats['conteo_cat']['Alto Rendimiento'].' estudiantes') : '—'; ?></span></div>
    <div class="cr"><span class="bc cat-sat">Satisfactorio</span><span style="font-weight:700"><?php echo $stats ? ($stats['conteo_cat']['Satisfactorio'].' estudiante(s)') : '—'; ?></span></div>
    <div class="cr"><span class="bc cat-basico">Basico</span><span style="font-weight:700"><?php echo $stats ? ($stats['conteo_cat']['Basico'].' estudiante(s)') : '—'; ?></span></div>
    <div class="cr"><span class="bc cat-bajo">Bajo</span><span style="font-weight:700"><?php echo $stats ? ($stats['conteo_cat']['Bajo'].' estudiante(s)') : '—'; ?></span></div>
  </div>
</div>
</div>

<div class="page" id="p-ranking">
<div class="topbar">
  <button class="btn-back" onclick="ir('home',document.querySelectorAll('.ptab')[0])">Inicio</button>
  <span class="topbar-title">Ranking Automático</span>
</div>
<div class="wrap">
  <header>
    <div class="iph xl"></div>
    <div class="badge">DEesafio 1</div>
    <h1>Ranking<br>Automático</h1>
    <p>Ordenado de mayor a menor · <?php echo count($registros); ?> estudiantes registrados</p>
  </header>

  <div class="card">
    <div class="stitle"><div class="iph md"></div>Tabla de Ranking </div>
    <div class="tw">
      <table>
        <thead><tr>
          <th>Posición</th><th>Nombre</th><th>Materia</th>
          <th style="text-align:center">Nota 1</th>
          <th style="text-align:center">Nota 2</th>
          <th style="text-align:center">Nota 3</th>
          <th style="text-align:center">Nota 4</th>
          <th>Promedio</th><th>Categoría</th>
        </tr></thead>
        <tbody>
          <?php if (!$stats): ?>
            <tr><td colspan="9" class="esvacio">Registra mínimo 5 estudiantes para ver el ranking.</td></tr>
          <?php else: ?>
            <?php foreach ($ranking as $i => $e): ?>
              <?php
                $posClass = "rp";
                switch ($i) {
                  case 0: $posClass = "rp gold"; break;
                  case 1: $posClass = "rp silver"; break;
                  case 2: $posClass = "rp bronze"; break;
                  default: $posClass = "rp"; break;
                }
                switch ($e['categoria']) {
                  case "Alto Rendimiento": $catClass="cat-alto"; break;
                  case "Satisfactorio":    $catClass="cat-sat"; break;
                  case "Basico":          $catClass="cat-basico"; break;
                  default:                $catClass="cat-bajo"; break;
                }
              ?>
              <tr>
                <td><span class="<?php echo $posClass; ?>"><?php echo $i+1; ?></span></td>
                <td style="font-weight:700"><?php echo htmlspecialchars($e['nombre']); ?></td>
                <td style="color:var(--accent3);font-size:.7rem"><?php echo htmlspecialchars($e['materia']); ?></td>
                <td class="nc"><?php echo $e['n1']; ?></td>
                <td class="nc"><?php echo $e['n2']; ?></td>
                <td class="nc"><?php echo $e['n3']; ?></td>
                <td class="nc"><?php echo $e['n4']; ?></td>
                <td class="an"><?php echo number_format($e['promedio'], 2); ?></td>
                <td><span class="bc <?php echo $catClass; ?>"><?php echo $e['categoria']; ?></span></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</div>

<script>
function ir(id, tab) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.ptab').forEach(t => t.classList.remove('on'));
  document.getElementById('p-' + id).classList.add('active');
  if (tab) tab.classList.add('on');
  window.scrollTo({top: 0, behavior: 'smooth'});
}

<?php if ($goto): ?>
(function(){
  var tabs = document.querySelectorAll('.ptab');
  switch ("<?php echo addslashes($goto); ?>") {
    case "registro": ir("registro", tabs[1]); break;
    case "estadisticas": ir("estadisticas", tabs[2]); break;
    case "ranking": ir("ranking", tabs[3]); break;
    default: ir("home", tabs[0]); break;
  }
})();
<?php endif; ?>
</script>
</body>
</html>

<?php
function clean_text($s) {
  $s = trim((string)$s);
  $s = preg_replace('/\s+/', ' ', $s);
  return $s;
}

function valid_nombre($nombre) { // solo se acepta mayusculas y minusculas en el nombre de la persona y espacion entre el nombre y el apellido de la persona 
  return (bool)preg_match('/^[\p{L}\s]+$/u', $nombre);
}

function nota_sanitizada($raw, &$warnings, $label) { //condiciones al momento de ingresar alguna calificacion de forma incorrecta 
  if (!is_numeric($raw)) { $warnings[] = $label . " inválida (no numérica). Se asignó 0."; return 0.0; }
  $n = (float)$raw;
  if ($n < 0 || $n > 10) { $warnings[] = $label . " fuera de rango (0 a 10). Se asignó 0."; return 0.0; }
  return $n;
}

function promedio($r) { return round(($r['n1'] + $r['n2'] + $r['n3'] + $r['n4']) / 4, 2); }

function categoria_por_prom($prom) { //si el estudiante paso la materia 
  switch (true) {
    case ($prom >= 9): return "Alto Rendimiento";
    case ($prom >= 8): return "Satisfactorio";
    case ($prom >= 7): return "Basico"; 
  }
}

function reprobo($prom) { return ($prom < 6): return "Bajo";  } //por si dejo la materia 

function build_detalle($registros) { //array de el estudiante 
  $detalle = [];
  foreach ($registros as $r) {
    $p = promedio($r);
    $detalle[] = [
      'nombre' => $r['nombre'],
      'materia'=> $r['materia'],
      'n1' => $r['n1'], 'n2' => $r['n2'], 'n3' => $r['n3'], 'n4' => $r['n4'],
      'promedio' => $p,
      'categoria' => categoria_por_prom($p),
      'reprobo' => reprobo($p),
    ];
  }
  return $detalle;
}

function ordenar_ranking($detalle) { // para ordenar a los estudiantes desde el mayor puntaje hasta el menor puntaje de el grupo de estudiantes 
  usort($detalle, function($a, $b){
    if ($a['promedio'] == $b['promedio']) return 0;
    return ($a['promedio'] < $b['promedio']) ? 1 : 0;
  });
  return $detalle;
}

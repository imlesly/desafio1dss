<?php
// session.php (sesiones)
session_start();

function ss_get($key, $default = null) {
  return isset($_SESSION[$key]) ? $_SESSION[$key] : $default;
}
function ss_set($key, $value) { $_SESSION[$key] = $value; }
function ss_flash($key, $value) { $_SESSION[$key] = $value; }
function ss_redirect($path) { header("Location: " . $path); exit; }

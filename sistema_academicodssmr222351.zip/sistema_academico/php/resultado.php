<?php
require_once __DIR__ . '/condicion.php'; 
// esto es para hacer un calculo general de todos los estudiantes 
function calcular_stats($registros) {
  $total = count($registros);
  if ($total < 5) return null;

  $detalle = build_detalle($registros);

  $sum = 0.0;
  foreach ($detalle as $e) { $sum += $e['promedio']; }
  $prom_general = round($sum / $total, 2);

  $mejor = null; $peor = null;
  foreach ($detalle as $e) {
    if ($mejor === null || $e['promedio'] > $mejor['promedio']) $mejor = $e;
    if ($peor  === null || $e['promedio'] < $peor['promedio'])  $peor  = $e;
  }

  $reprobados = 0;
  foreach ($detalle as $e) { if ($e['reprobo']) $reprobados++; }
  $porc_reprob = round(($reprobados / $total) * 100, 1);

  $conteo_cat = ["Alto Rendimiento"=>0,"Satisfactorio"=>0,"Basico"=>0,"Bajo"=>0];
  foreach ($detalle as $e) {
    $c = $e['categoria'];
    if (isset($conteo_cat[$c])) $conteo_cat[$c]++;
  }

  $mensajes = [];
  if ($prom_general >= 9) { $mensajes[] = ['tipo'=>'perfecto','texto'=>'Grupo perfecto']; }
  else if ($prom_general >= 8) { $mensajes[] = ['tipo'=>'excelencia','texto'=>'Grupo de excelencia academica']; }

  return [
    'total'=>$total,'detalle'=>$detalle,'prom_general'=>$prom_general,
    'mejor'=>$mejor,'peor'=>$peor,'reprobados'=>$reprobados,'porc_reprob'=>$porc_reprob,
    'conteo_cat'=>$conteo_cat,'mensajes'=>$mensajes
  ];
}

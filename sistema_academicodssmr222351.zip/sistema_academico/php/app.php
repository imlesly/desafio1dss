<?php
require_once __DIR__ . '/session.php';
require_once __DIR__ . '/condicion.php';
require_once __DIR__ . '/resultado.php';

$accion = filter_input(INPUT_POST, 'accion', FILTER_SANITIZE_SPECIAL_CHARS);
// filter_input que obtiene los datos mediante el formulario de index.php y INPUT_POST indica que viene de un post y el FILTER_SANITIZE_SPECIAL_CHARS para evitar inyecciones de html 
if ($accion === null || $accion === false || $accion === '') {
  ss_flash('flash_error', 'Acción inválida.');  // ss_flash guarda un mensaje de error en sesion 
  ss_redirect('../index.php'); // esto es para volver al index
}

$registros = ss_get('registros', []);
$warnings  = [];

switch ($accion) {

  case 'agregar':
    $nombre  = filter_input(INPUT_POST, 'nombre', FILTER_UNSAFE_RAW); // FILTER_UNSAFE_RAW obtiene valores sin limpiar 
    $materia = filter_input(INPUT_POST, 'materia', FILTER_UNSAFE_RAW);

    $nombre  = clean_text($nombre);
    $materia = clean_text($materia);

    if ($nombre === '' || !valid_nombre($nombre)) {
      ss_set('warnings', []);
      ss_flash('flash_error', 'Nombre inválido. Solo letras y espacios.');
      ss_set('goto', 'registro');
      ss_redirect('../index.php');
    }

    if ($materia === '') {
      ss_set('warnings', []);
      ss_flash('flash_error', 'Selecciona una materia.');
      ss_set('goto', 'registro');
      ss_redirect('../index.php');
    }

    $n1 = filter_input(INPUT_POST, 'n1', FILTER_UNSAFE_RAW);
    $n2 = filter_input(INPUT_POST, 'n2', FILTER_UNSAFE_RAW);
    $n3 = filter_input(INPUT_POST, 'n3', FILTER_UNSAFE_RAW);
    $n4 = filter_input(INPUT_POST, 'n4', FILTER_UNSAFE_RAW);

    $n1 = nota_sanitizada($n1, $warnings, 'Nota 1');
    $n2 = nota_sanitizada($n2, $warnings, 'Nota 2');
    $n3 = nota_sanitizada($n3, $warnings, 'Nota 3');
    $n4 = nota_sanitizada($n4, $warnings, 'Nota 4');

    $nuevo = ['nombre'=>$nombre,'materia'=>$materia,'n1'=>$n1,'n2'=>$n2,'n3'=>$n3,'n4'=>$n4];

    $registros[] = $nuevo;
    ss_set('registros', $registros);

    $stats = calcular_stats($registros);
    ss_set('stats', $stats);

    if ($stats !== null) ss_set('ranking', ordenar_ranking($stats['detalle']));
    else ss_set('ranking', []);

    ss_set('warnings', $warnings);

    $prom = promedio($nuevo);
    $cat  = categoria_por_prom($prom);
    ss_flash('flash_ok', 'Registro enviado correctamente. <strong>' . htmlspecialchars($nombre) . '</strong> — ' . htmlspecialchars($materia) . ' — Promedio: <strong>' . number_format($prom,2) . '</strong> (' . $cat . ')');

    ss_set('goto', 'registro');
    ss_redirect('../index.php');
    break;

  case 'eliminar':
    $idx = filter_input(INPUT_POST, 'idx', FILTER_VALIDATE_INT);
    if ($idx === null || $idx === false || $idx < 0 || $idx >= count($registros)) {
      ss_flash('flash_error', 'Índice inválido.');
      ss_set('goto', 'registro');
      ss_redirect('../index.php');
    }

    array_splice($registros, $idx, 1);
    ss_set('registros', $registros);

    $stats = calcular_stats($registros);
    ss_set('stats', $stats);

    if ($stats !== null) ss_set('ranking', ordenar_ranking($stats['detalle']));
    else ss_set('ranking', []);

    ss_set('warnings', []);
    ss_flash('flash_ok', 'Registro eliminado.');
    ss_set('goto', 'registro');
    ss_redirect('../index.php');
    break;

  case 'eliminar_todos':
    ss_set('registros', []);
    ss_set('stats', null);
    ss_set('ranking', []);
    ss_set('warnings', []);
    ss_flash('flash_ok', 'Todos los registros fueron eliminados.');
    ss_set('goto', 'registro');
    ss_redirect('../index.php');
    break;

  case 'limpiar':
    ss_set('warnings', []);
    ss_flash('flash_ok', 'Formulario limpiado.');
    ss_set('goto', 'registro');
    ss_redirect('../index.php');
    break;

  default:
    ss_flash('flash_error', 'Acción no soportada.');
    ss_redirect('../index.php');
    break;
}
